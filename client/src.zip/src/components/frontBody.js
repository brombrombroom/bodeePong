import React from "react";
import "./frontBody.css";
class frontBody extends React.Component {
  render() {
    return (
      <div className="frontBody badge-pill">
        <div id="gameImg">
          <h3>game img goes here</h3>
        </div>
      </div>
    );
  }
}

export default frontBody;
